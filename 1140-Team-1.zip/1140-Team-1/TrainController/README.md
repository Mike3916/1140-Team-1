README.md

Download the up-to-date .zip file containing all program files from /bin/release
