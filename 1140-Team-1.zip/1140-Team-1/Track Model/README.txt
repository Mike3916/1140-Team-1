README

Download .zip file in \bin\release

Run .exe