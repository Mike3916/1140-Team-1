﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrackModel_v0._1
{
    internal class Yard : Block
    {
        public Yard()
        {
            mblockNum = 0;

        }

        int mblockNum;
        string mInfrastructure;


        string[] mblockInfo;
    }
}
