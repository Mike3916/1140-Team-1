﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrackModel_v0._1
{
    internal class TrackModel
    {
        public int main()
        {
            MainWindow UI = new MainWindow();
            UI.Show();
            return 0;
        }
    }
}
