﻿namespace WaysideController1._01
{
    public class Class1
    {

    }
}